<?php
// define application constants
define('GW_UPLOADPATH', 'images/');
define('GW_MAXFILESIZE', 51200) // 51 KB
?>