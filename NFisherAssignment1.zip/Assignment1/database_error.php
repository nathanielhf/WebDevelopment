<!DOCTYPE html>
<html>
<head>
	<title>Book Application</title>
</head>
<body>
<main>
	<h1>Database Error</h1>
	<p>There was an error connecting to the database.</p>
	<p>The database must be installed as described in the appendix.</p>
	<p>The database must be running as described in chapter 1.</p>
	<p>Error message: <?php echo $error_message; ?></p>
</main>
</body>
</html>