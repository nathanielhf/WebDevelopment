<?php
    //connect to our database 
    $dbc = mysqli_connect('localhost', 'root', '@NicolaZoe!1', 'db_books')
    or die('Error connecting to MySQL server.');
?>